#include<stdio.h>
int main()
{
    int x =-5;
    printf("x++: %d \n",x);
    printf("++x: %d\n",x+1);
    printf("x--: %d\n",x);
    printf("--x: %d",x-1);
}
