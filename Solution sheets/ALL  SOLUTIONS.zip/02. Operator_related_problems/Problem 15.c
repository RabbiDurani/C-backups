#include<stdio.h>
int main()
{
    int i;
    float f;
    double d;
    char c;
    printf("size of int=%dbytes\n",sizeof(i));
    printf("size of float=%dbytes\n",sizeof(f));
    printf("size of double=%dbytes\n",sizeof(d));
    printf("size of char=%dbytes\n",sizeof(c));
}
