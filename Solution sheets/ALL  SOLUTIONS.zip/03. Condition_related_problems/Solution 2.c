#include<stdio.h>
int main()
{
    int num;

    printf("Enter any number :");

    scanf("%f",&num);

    if(num%2==0)

        printf("Even");

    else

        printf("odd");
}
