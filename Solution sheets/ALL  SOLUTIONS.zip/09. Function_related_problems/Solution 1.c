#include<stdio.h>
void Print()
{
    printf("This is a function");
}
void main()
{
    Print();
}
