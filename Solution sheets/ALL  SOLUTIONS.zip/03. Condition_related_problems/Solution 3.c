#include<stdio.h>
int main()
{
   int num;

   printf("Enter any number between 0-9 :");

   scanf("%d",&num);

   if(num==0)
   printf("Zero\n");

    if(num==1)
   printf("One\n");

    if(num==2)
   printf("Two\n");

    if(num==3)
   printf("Three\n");

    if(num==4)
   printf("Four\n");

    if(num==5)
   printf("Five\n");

    if(num==6)
   printf("Six\n");

    if(num==7)
   printf("Seven\n");

    if(num==8)
   printf("Eight\n");

    if(num==9)
   printf("Nine\n");

}
