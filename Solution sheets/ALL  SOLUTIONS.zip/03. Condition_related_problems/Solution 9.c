#include<stdio.h>
int main()
{
    char ch;
    printf("Enter any character :");
    scanf("%c",&ch);

    if(ch>=65 && ch<=90)
        printf("Alphabet");
    else if(ch>=97 && ch<=122)
        printf("Alphabet");
    else if(ch>=48 && ch<=57)
        printf("Digit");
    else
        printf("Special");
}
  else if(num>0)
    {
        temp=num;
        flag=0;

        while(temp!=1)
        {
            if(temp%2!=0)
            {
                flag=1;
                break;
            }
            temp=temp/2;
        }
        if(flag==0)
            printf("%d is Power of 2");
            else
                ("%d is not Power of 2");
    }
