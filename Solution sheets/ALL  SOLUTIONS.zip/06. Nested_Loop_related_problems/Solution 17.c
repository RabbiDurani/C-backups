#include<stdio.h>
int main()
{
    int i,j,n,k,a,b,q,r;

    printf("Enter N :");
    scanf("%d",&n);

    k=(n+1)/2;
    a=k-1;
    b=k+1;
    q=2;
    r=n-1;
    for(i=1; i<=k; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(j==k)
            {
                printf("$");
            }
            else if(i>1 && j==a || i>1 && j==b)
            {
                printf("$");
            }
            else if(i==k)
            {
                printf("$");
            }
            else
            {
                printf("-");
            }
        }

        if(i>1)
        {
            a--;
            b++;
        }
        printf("\n");
    }

    for(i=1; i<=k-1; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(j==k)
            {
                printf("$");
            }
            else if(i>=1 && j==q ||i>=1 && j==r)
            {
                printf("$");
            }
            else
            {
                printf("-");
            }
        }
        q++;
        r--;
        printf("\n");
    }
}
